'this is the payload baby

Randomize

Set WshShell = CreateObject("WScript.Shell")
Set AppShell = CreateObject("Shell.Application")

Set FileSystem = CreateObject("Scripting.FileSystemObject")
Dim scriptDir
scriptDir = FileSystem.GetParentFolderName(WScript.ScriptFullName)

Dim nirCmd
nirCmd = scriptDir & "\nircmd.exe"

Dim choicesVbs
choicesVbs = scriptDir & "\choices.vbs"

Dim userProfilePath
userProfilePath = WshShell.ExpandEnvironmentStrings("%userprofile%")

Dim happyBirthdayCollin
happyBirthdayCollin = scriptDir & "\beautiful.mp3"

Dim whispers
whispers = scriptDir & "\whispers.mp3"

Dim niceSoundingHappyBirthday
niceSoundingHappyBirthday = scriptDir & "\istolethissongimnottalentedenoughsorry.mp3"


Function RunNircmd(command)
    WshShell.Run """" & nircmd & """ " & command
End Function


WshShell.Run """C:\Program Files (x86)\Windows Media Player\wmplayer.exe""", 0 ,false
WScript.Sleep 2000
WshShell.SendKeys " "
WScript.Sleep 100
WshShell.SendKeys "{ENTER}"
WScript.Sleep 2000

msgBox "happy birthday coleslaw!!!"
RunNircmd "killprocess wmplayer.exe"
WScript.Sleep 1000


Dim lastStartForSong
lastStartForSong = 0
Dim songLength
songLength = 43
Dim ongoingSong
ongoingSong = false

Function PlaySong(path)
    WshShell.Run """C:\Program Files (x86)\Windows Media Player\wmplayer.exe"" """ & path & """", 0, false
    RunNircmd "setappvolume wmplayer.exe 1"
    lastStartForSong = Timer
    RunNircmd "setsysvolume 65535"
    ongoingSong = true
    'RunNircmd "script ""inline: loop 60 1000 setappvolume wmplayer.exe 1 \n setsysvolume 65535"""
End Function

PlaySong happyBirthdayCollin

Dim sleepAmount
sleepAmount = 20.000

Dim minSleep
minSleep = 1.5000

Dim sleepStep
sleepStep = 1.000

Dim startTime
startTime = Timer


Dim arthritis
arthritis = false
Dim lastArthritis
lastArthritis = 0

Dim typeHappyBirthdayVbs
typeHappyBirthday = 0

Function NumberBetween(min,max)
    Randomize
    intNum = Int((max - min + 1) * Rnd + min)
    NumberBetween = intNum
End Function


Function RandomPayload(time)
    Randomize
    Dim rng
    rng = Rnd
    If (rng<0.2) Then
        If (ongoingSong) Then
            Exit Function
        End If
        rng = Rnd
        if (rng < 0.45) Then
            PlaySong happyBirthdayCollin
            songLength = 43
        ElseIf (rng < 0.9) Then
            PlaySong whispers
            songLength = 35
        Else
            PlaySong niceSoundingHappyBirthday
            songLength = 65
        End If
        Exit Function
    End If
    If (rng<0.4) Then
        WshShell.Run "https://www.youtube.com/watch?v=D89fHW6cbZU"
        Exit Function
    End If
    If (rng<0.6) Then
        arthritis = true
        lastArthritis = Timer
        RunNircmd "loop 100 100 movecursor 3 3"
                
        Exit Function
    End If
    If (rng<0.8) Then
        typeHappyBirthday = 5
        Exit Function
    End If
    WshShell.Run "cmd.exe /c start """" ""wscript.exe"" """ & choicesVbs & """",0,false
    rng = Rnd

End Function

Do While 2>1
    If Timer - startTime > sleepAmount Then
        startTime = Timer
        RandomPayload startTime
        If sleepAmount>minSleep Then
            sleepAmount = sleepAmount - sleepStep
            if (sleepAmount<minSleep) Then
                sleepAmount = minSleep
            End If
        End If
    End If

    If ongoingSong Then
        If (Timer - lastStartForSong > songLength) Then
            ongoingSong = false
            RunNircmd "killprocess wmplayer.exe"
        End If
    End If
    
    If arthritis Then
        If (Timer - lastArthritis > 10) Then
            arthritis = false
        End If
    End If
    
    If (typeHappyBirthday>0) Then
        typeHappyBirthday = typeHappyBirthday - 1
        WshShell.SendKeys "happy birthday collin! "
    End If
    WScript.Sleep 100
Loop