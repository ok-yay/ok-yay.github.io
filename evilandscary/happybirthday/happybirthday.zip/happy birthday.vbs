'this is the payload baby

Set WshShell = CreateObject("WScript.Shell")
Set AppShell = CreateObject("Shell.Application")

Dim userProfilePath
userProfilePath = WshShell.ExpandEnvironmentStrings("%userprofile%")

Dim folderPath
folderPath = userProfilePath & "\Documents\HappyBirthday"

msgBox "happy birthday coleslaw!!!"

'WshShell.Run "cmd.exe /c nircmd.exe win hide title ""Magnifier""", 1, true

WshShell.Run "cmd.exe /c nircmd.exe qboxcom ""Are you having a happy birthday?"" ""Happy Birthday Coleslaw"" exitwin reboot"

'Do While 2>1
'	WScript.Sleep 1000
'	WshShell.SendKeys "happy birthday! "
'	WshShell.SendKeys "^%i"
'	msgBox "goog"
'Loop

powershell -Command ""Expand-Archive -Path 'C:\path\to\file.zip' -DestinationPath 'C:\path\to\destination'"""